from database import Database
from student import Student
from analysis import PerformanceAnalysis

def insert_student(db, student):
    db.cursor.execute("""
    INSERT INTO students VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (student.sid, student.name, student.dept,
          student.attendance,
          student.marks[0], student.marks[1], student.marks[2]))
    db.conn.commit()

def display_report(db):
    db.cursor.execute("SELECT * FROM students")
    records = db.cursor.fetchall()

    analysis = PerformanceAnalysis()

    print("\nSTUDENT PERFORMANCE REPORT")
    print("-" * 60)

    for r in records:
        avg = (r[4] + r[5] + r[6]) / 3
        grade = analysis.calculate_grade(avg)
        print(f"ID:{r[0]} Name:{r[1]} Avg:{avg:.2f} Grade:{grade}")

# ---------- PROGRAM START ----------
db = Database()
db.create_table()

s1 = Student(1, "Sai", "CSE", 85, 78, 82, 80)
s2 = Student(2, "Rahul", "ECE", 72, 65, 60, 58)

insert_student(db, s1)
insert_student(db, s2)

display_report(db)
