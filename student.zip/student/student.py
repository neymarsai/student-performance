class Student:
    def __init__(self, sid, name, dept, attendance, m1, m2, m3):
        self.sid = sid
        self.name = name
        self.dept = dept
        self.attendance = attendance
        self.marks = [m1, m2, m3]

    def total_marks(self):
        return sum(self.marks)

    def average_marks(self):
        return self.total_marks() / 3
