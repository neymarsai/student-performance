class PerformanceAnalysis:
    def calculate_grade(self, average):
        if average >= 80:
            return "A"
        elif average >= 60:
            return "B"
        elif average >= 40:
            return "C"
        else:
            return "Fail"
