import sqlite3

class Database:
    def __init__(self):
        self.conn = sqlite3.connect("student.db")
        self.cursor = self.conn.cursor()

    def create_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS students(
            student_id INTEGER PRIMARY KEY,
            name TEXT,
            department TEXT,
            attendance INTEGER,
            marks1 INTEGER,
            marks2 INTEGER,
            marks3 INTEGER
        )
        """)
        self.conn.commit()
